# Contributing

Everyone is more than welcome contribute to Photo View! You reached this file, it means that there is a good chance of you considering this. for that, there is some small points that can be considered obicous, but there is always a need for rememberance:

- Use english. Photo view is used by people around the globe, your message will probably help more people when you use english.
- Verify if your report/bugfix/any contribution is not a duplicate instance of the same content. In other words, see if someone hast said what you are saying before. '


