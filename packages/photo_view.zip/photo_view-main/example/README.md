# Example app

The source code for the example app.

After cloning, run the following command inside this directory:

```
flutter create .
```
