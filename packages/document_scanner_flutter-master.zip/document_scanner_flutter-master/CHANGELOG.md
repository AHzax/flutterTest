## 0.0.1

* Implemented Android Document Scanner Libarary

## 0.1.1

* Implemented iOS Document Scanner Libarary
* Migrated to null-safety
* Implemented Manual Source Selection

## 0.1.2

* Added doc
* Improved description
* Updated README
## 0.2.0

* Added PDF Generator Feature
* Fixed Android Scanner bugs
* Implemented Android scanner labels customization feature
## 0.2.1

* Fixed iOS compilation issue
## 0.2.2

* Fixed Android compilation issue for file provider
* Fixed Delete button on scanned images gird
## 0.2.3

* Added more labels to android scanner
* Removed unwanted action bar from android scanner
* Removed unwanted low memory warning from android scanner
* PDF Mode can now enforce source selection for scanning
  
## 0.2.4

* Fixed PDF gallery rendering issue on release build

## 0.2.5

* Safe area UI fixes