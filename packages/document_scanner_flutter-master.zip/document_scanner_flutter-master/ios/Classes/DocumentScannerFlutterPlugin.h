#import <Flutter/Flutter.h>

@interface DocumentScannerFlutterPlugin : NSObject<FlutterPlugin>
@end
